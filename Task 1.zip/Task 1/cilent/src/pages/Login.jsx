import { Button, Form, Input } from 'antd'
import React from 'react'
import {  useNavigate } from 'react-router-dom'
import { toast }  from "react-toastify"
import axios from 'axios';

function Login() {
  const navigate = useNavigate();
  const onFinish = async (values) => {
    try {
     
      const response = await axios.post("https://dummyjson.com/auth/login", values);
        console.log(response.data);
        toast.success("Login Successfully");
        localStorage.setItem("token", response.data['token']);
        navigate("/home");
      
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong");
    }
  };
  return (
    <div className='authenication'>
        <div className="authenication-form card p-3">
        <h1 className="card-title">Login</h1>
        <Form layout="vertical"  onFinish={onFinish}>
         

          <Form.Item required label="Username" name="username" rules={[{ required: true }]}>
            <Input placeholder="Username" />
          </Form.Item>

          <Form.Item required label="Password" name="password"  rules={[{ required: true }]}>
            <Input placeholder="Password" type="password" />
          </Form.Item>

          <Button className="primary-button my-2" htmlType='submit'>
            login
          </Button>
        </Form>

        {/* <Link to="/register" className="anchor mt-2">
          Click Here To Register
        </Link> */}
      </div>
    </div>
  )
}

export default Login