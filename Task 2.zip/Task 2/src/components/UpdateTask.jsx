import React from 'react'

function UpdateTask() {
  return (
    <div>UpdateTask</div>
  )
}

export default UpdateTask